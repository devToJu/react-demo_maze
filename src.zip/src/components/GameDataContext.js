import { createContext } from "react";

export const GameDataContext = createContext();